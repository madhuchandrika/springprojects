package com.cg.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;


public class EmployeeClient {
	public static void main(String args[])throws Exception {
		ApplicationContext ctx=SpringApplication.run(EmployeeClient.class, args);
		User user=(User) ctx.getBean("u");
		
		System.out.println(user.getId());
		System.out.println(user.getUserName());
		System.out.println(user.getSalary());
		System.out.println(user.getBu());
		System.out.println(user.getAge());
		
	}
}
