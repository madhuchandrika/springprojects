package com.cg.employee;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("u")
public class Employee {
	@Value("${id}")
	private String id;
	@Value("${userName}")
	private String userName;
	@Value("${salary}")
	private String salary;
	@Value("${bu}")
	private String bu;
	@Value("${age}")
	private String age;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	userName = userName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getBu() {
	return bu;
}
public void setBu(String bu) {
	this.bu = bu;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

}
