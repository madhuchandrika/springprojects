package demomvc1;

import com.cg.mvc.Date;
import com.cg.mvc.ModelAndView;
@RequestMapping("/hello")
public class MyController {
	public ModelAndView sayHello() {
		String today=new Date().toString();
		return new Mo
	}
}
