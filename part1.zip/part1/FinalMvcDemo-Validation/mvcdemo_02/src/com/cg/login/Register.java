package com.cg.login;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class Register {
	@NotEmpty
	@Size(min=4,max=8,message="Please enter the firstname")
	private String firstname;
	@NotEmpty
	@Size(min=4,max=8,message="Please enter the lastname")
	private String lastname;
	
	private char gender;
	@NotEmpty
	@Email(message="Enter a valid email")
	private String email;
	private String [] skillset;
	private String city;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String[] getSkillset() {
		return skillset;
	}
	public void setSkillset(String[] skillset) {
		this.skillset = skillset;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
