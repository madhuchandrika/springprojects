package com.cg.controller;

import java.sql.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class MyController {
@RequestMapping("/hello")
public ModelAndView sayHello() {
	String today= new Date(0).toString();
	return new ModelAndView("hello","today123",today);
}
}
