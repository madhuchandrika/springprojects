package com.cg.empapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.empapp.bean.Employee;
import com.cg.empapp.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	@RequestMapping("/api/employees")
  public List<Employee> getAllEmployee(){
	return employeeService.getAllEmployees();
}
	
	@RequestMapping("/api/employees/{id}")
	public Employee getEmployees(@PathVariable int id){
		return employeeService.getEmployeeById(id);
	}
	@RequestMapping(value="/api/employees/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable int id){
		employeeService.deleteEmployee(id);
		return new ResponseEntity<String>("Employee with the id" +id+ "deleted",HttpStatus.OK);
	}
	@PostMapping("/api/employees")
	//@RequestMapping(value="/api/employees",method=RequestMethod.POST)
	public ResponseEntity<String> addEmployee(@RequestBody Employee emp){
		employeeService.addEmployee(emp);
		return new ResponseEntity<String>("Employee Successfully added",HttpStatus.OK);
	}
	@PostMapping("/api/employees/{id}")
	//@RequestMapping(value="/api/employees/{id}",method=RequestMethod.PUT)
	public ResponseEntity<String> updateEmployee(@RequestBody Employee emp){
		employeeService. updateEmployee(emp);
		return new ResponseEntity<String>("Employee Successfully update",HttpStatus.OK);
	}
	@RequestMapping("/api/employees/gender")
	public List<Employee> getEmployeeByGender(@RequestParam String gender){
		return employeeService.getEmployeeByGender(gender);
	}
}
